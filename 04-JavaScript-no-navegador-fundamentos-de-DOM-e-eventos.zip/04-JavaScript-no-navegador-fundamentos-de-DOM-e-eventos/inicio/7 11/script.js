"use strict"; // Define o modo estrito para evitar erros comuns.
